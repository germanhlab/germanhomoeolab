import React from 'react'

const page = () => {
    return (
        <div className=' w-full'>

            {/* <div className='c-wrapperBlack w-full flex-center'>
                <p className="text-lg text-white paddings">
                    About Us
                </p>


            </div>
            <br />

            <div className=''>
                <p className="text-medium text-black paddings">
                    Welcome to German Homoeo Lab 
                </p>
            </div> */}

            <div class="about-section">
            <h1 className="text-lg text-black font-bold">About Us</h1>
          <div class="border"></div>
          <div class="about-section-row">
            <div class="about-section-col">
              <div class="about">
                <p>
                We create a new era in Homoeopathy treatment.For more than one decade we serve the people and built their trust.We have a panel of expertise Doctor who are attend our patient on 24 hours basis.We always try to give a better service to our patient at their door.
                 </p>

                 <p>
                 We are German Homoeo Lab. A renowned leading Homoeopathy Clinic of West Bengal.Presently we spread our wings on Lucknow.Very recent try to spread it all over India.Over a decade our Expertise 
                 team work hard to give a Best treatment to our Patients through out the day.We always give a Quality treatment by a Quality Medicine and Quality People.
                 </p> 
                  
                {/* <a href="#">Read More</a> */}
              </div>
            </div>
            {/* <div class="about-section-col">
              <div class="skills">
                <div class="skill">
                  <div class="title">Web Develpor</div>
                  <div class="progress">
                    <div class="progress-bar p1"><span>90%</span></div>
                  </div>
                </div>
 
                <div class="skill">
                  <div class="title">UI Design</div>
                  <div class="progress">
                    <div class="progress-bar p2"><span>70%</span></div>
                  </div>
                </div>
 
                <div class="skill">
                  <div class="title">UX Design</div>
                  <div class="progress">
                    <div class="progress-bar p3"><span>50%</span></div>
                  </div>
                </div>
              </div>
            </div> */}
          </div>
        </div>


        </div>

    )
}

export default page