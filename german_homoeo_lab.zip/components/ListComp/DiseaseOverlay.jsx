import React from 'react'
import './Disease.css'
import Disease from './Disease'

const DiseaseOverlay = () => {
  return (
    <section className='c-wrapperMain paddings'>
        <Disease/>
    </section>
    // <section className='c-wrapper '>
    //      <span className='paddings innerwidth flexCenter primaryText text-medium '>German Homoeo Lab</span>
    //      <br/>
    //      <span className='  innerwidth flexCenter orangeText'>For all types of chronic disease & panchakarma treatments</span>
    //      <br/>
    //      <span className='  innerwidth flexCenter orangeText'>In the modern society, education, culture everything speaks about materialism if this is everything then why is it so that most of us are unhappy. There is unrest, anxiety, mental tension, fights & terror everywhere despite best efforts to stop them.</span>
    //      <br/>
    //      <span className='  innerwidth flexCenter orangeText'>In this junction of present times AYURVEDA is the only answer for us which includes holistic science of health & longevity. It is a philosophy for healing the person as a whole, body & mind.</span>
    //      <br/>
    //      <span className='  innerwidth flexCenter orangeText'>Ayusya Ayurvedic Superspeciality Treatment Center was founded with the mission of caring people though natural ways. Our objective is to make people ailment free, healthy, through proper ayurvedic treatment, Panchakarma Treatment & life style management. We have our presence in the Eastern part of India with three clinics in Kolkata, one in Howrah.</span>
    //      <br/>
    //      <span className='  innerwidth flexCenter orangeText'>We have a long term vision that a day will come when most of the people will opt for ayurvedic, natural treatments apart from modern conventional treatment which comes with major side effects.</span>
               
    //     <div className="paddings innerwidth flexCenter c-container">
    //         <img src='./box.png' alt=''/>
    //         <img src='./box.png' alt=''/>
    //         <img src='./box.png' alt=''/>
    //     </div>
    //     <div className="paddings innerwidth flexCenter c-container">
    //         <img src='./box.png' alt=''/>
    //         <img src='./box.png' alt=''/>
    //         <img src='./box.png' alt=''/>
    //     </div>
    //     <div className="paddings innerwidth flexCenter c-container">
    //         <img src='./box.png' alt=''/>
    //         <img src='./box.png' alt=''/>
    //         <img src='./box.png' alt=''/>
    //     </div>
    //     <div className=" innerwidth flexCenter">
    //     <button className=' button'>
    //                 <a href="">View More</a>
    //     </button>
    //     </div>
        

    // </section>
  )
}

export default DiseaseOverlay